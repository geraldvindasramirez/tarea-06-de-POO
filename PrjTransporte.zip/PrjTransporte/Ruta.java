import java.util.ArrayList;

public class Ruta {
    private String codigo;
    private String nombre;
    private double tarifa;
    private ArrayList<Parada> misParadas;
    private ArrayList<HorarioSalida> misHorarios;

    public Ruta(String pCodigo, String pNombre, double pTarifa) {
        codigo = pCodigo;
        nombre = pNombre;
        tarifa = pTarifa;
        misParadas = new ArrayList<>();
        misHorarios = new ArrayList<>();
    }

    public String getNombre() { return nombre; }
    public double getTarifa() { return tarifa; }

    public void agregarParada(Parada pParada) {
        if (!misParadas.contains(pParada)) {
            misParadas.add(pParada);
        }
    }

    public void registrarSalida(int pHora, int pMinuto) {
        if (pHora >= 0 && pHora <= 23 && pMinuto >= 0 && pMinuto <= 59) {
            misHorarios.add(new HorarioSalida(pHora, pMinuto));
        }
    }

    public void registrarSalida(int pHora) {
        registrarSalida(pHora, 0);
    }

    public String consultarNombresParadas() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < misParadas.size(); i++) {
            sb.append(misParadas.get(i).getNombre());
            if (i < misParadas.size() - 1) sb.append(", ");
        }
        return sb.toString();
    }

    public String consultarHorariosSalida() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < misHorarios.size(); i++) {
            sb.append(misHorarios.get(i).toString());
            if (i < misHorarios.size() - 1) sb.append(", ");
        }
        return sb.toString();
    }

    public String toString() {
        return "Ruta: " + codigo + " - " + nombre + " | Tarifa: ₡" + tarifa + 
               " | Paradas: " + consultarNombresParadas() + 
               " | Horarios: " + consultarHorariosSalida();
    }
}