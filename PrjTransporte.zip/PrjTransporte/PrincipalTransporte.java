public class PrincipalTransporte {
    public static void main(String[] args) {
        System.out.println("=== PRUEBA SISTEMA DE TRANSPORTE - Gerald Vindas ===");

        // 1. Crear Paradas
        Parada p1 = new Parada("P01", "Terminal Central");
        Parada p2 = new Parada("P02", "Parque Limón");
        Parada p3 = new Parada("P03", "TEC Limón");

        // 2. Crear Ruta y asociar paradas y horarios
        Ruta ruta1 = new Ruta("R-01", "Ruta Centro - TEC", 500.0);
        ruta1.agregarParada(p1);
        ruta1.agregarParada(p2);
        ruta1.agregarParada(p3);

        ruta1.registrarSalida(6, 30);
        ruta1.registrarSalida(12, 15);
        ruta1.registrarSalida(17, 0);

        // 3. Crear Bus y asignar Ruta
        Bus bus1 = new Bus("L-1020", 40);
        bus1.asignarRuta(ruta1);

        // 4. Crear Personas con distintas condiciones
        Persona per1 = new Persona("Carlos Pérez", "regular");
        Persona per2 = new Persona("María Gómez", "estudiante");
        Persona per3 = new Persona("Don Julio", "ciudadano de oro");

        // 5. Cobrar pasajes
        bus1.cobrarPasaje(per1); // Paga tarifa completa (500)
        bus1.cobrarPasaje(per2); // Paga con 50% descuento (250)
        bus1.cobrarPasaje(per3); // Paga gratis (0)

        // 6. Mostrar resultados en consola
        System.out.println(ruta1);
        System.out.println(bus1);
    }
}