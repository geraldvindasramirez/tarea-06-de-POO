public class Persona {
    private String nombre;
    private String condicion; // "regular", "estudiante", "ciudadano de oro"

    public Persona(String pNombre, String pCondicion) {
        nombre = pNombre;
        condicion = pCondicion.toLowerCase();
    }

    public Persona(String pNombre) {
        this(pNombre, "regular");
    }

    public String getNombre() { return nombre; }
    public String getCondicion() { return condicion; }

    public String toString() {
        return "Persona: " + nombre + " (" + condicion + ")";
    }
}