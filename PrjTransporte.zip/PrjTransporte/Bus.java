public class Bus {
    private String placa;
    private int capacidad;
    private String codigo;
    private static int cantidadBuses = 0;
    private Ruta rutaAsignada;
    private double totalRecaudado;
    private int personasAtendidas;

    public static final String PREFIJO_BUS = "BUS-";

    public Bus(String pPlaca, int pCapacidad) {
        placa = pPlaca;
        capacidad = pCapacidad;
        cantidadBuses++;
        codigo = PREFIJO_BUS + cantidadBuses;
        rutaAsignada = null;
        totalRecaudado = 0.0;
        personasAtendidas = 0;
    }

    public String getCodigo() { return codigo; }

    public void asignarRuta(Ruta pRuta) {
        rutaAsignada = pRuta;
    }

    public String consultarNombreRuta() {
        if (rutaAsignada == null) {
            return "(sin ruta asignada)";
        }
        return rutaAsignada.getNombre();
    }

    public void cobrarPasaje(Persona pPersona) {
        if (rutaAsignada == null) {
            return;
        }

        double tarifaBase = rutaAsignada.getTarifa();
        double montoCobrar = 0.0;

        switch (pPersona.getCondicion()) {
            case "estudiante":
                montoCobrar = tarifaBase * 0.5; // 50% descuento
                break;
            case "ciudadano de oro":
                montoCobrar = 0.0; // 100% descuento
                break;
            case "regular":
            default:
                montoCobrar = tarifaBase;
                break;
        }

        totalRecaudado += montoCobrar;
        personasAtendidas++;
    }

    public static int getCantidadBuses() {
        return cantidadBuses;
    }

    public String toString() {
        return "Bus [" + codigo + "] | Placa: " + placa + " | Capacidad: " + capacidad + 
               " | Ruta Asignada: " + consultarNombreRuta() + 
               " | Personas Atendidas: " + personasAtendidas + 
               " | Total Recaudado: ₡" + totalRecaudado;
    }
}