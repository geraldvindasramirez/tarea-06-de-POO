public class PrincipalEdificio {
    public static void main(String[] args) {
        System.out.println("=== PRUEBA EDIFICIOS - Gerald Vindas ===");

        // Edificio 1
        Edificio ed1 = new Edificio("Torre Tecnológica");
        ed1.registrarPiso(450.5, 120, "Laboratorios");
        ed1.registrarPiso(300.0, 80, "Oficinas Administrativas");

        // Edificio 2 (Demuestra la independencia en la numeración de pisos)
        Edificio ed2 = new Edificio("Centro de Idiomas");
        ed2.registrarPiso(250.0, 50, "Aulas");
        ed2.registrarPiso(200.0, 30, "Auditorio");

        System.out.println(ed1);
        System.out.println(ed2);
    }
}