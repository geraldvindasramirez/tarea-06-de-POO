import java.util.ArrayList;

public class Edificio {
    private String nombre;
    private ArrayList<Piso> misPisos;

    public Edificio(String pNombre) {
        nombre = pNombre;
        misPisos = new ArrayList<>();
    }

    public void registrarPiso(double pArea, int pCapacidad, String pUso) {
        int numeroAsignado = misPisos.size() + 1;
        misPisos.add(new Piso(numeroAsignado, pArea, pCapacidad, pUso));
    }

    public void registrarPiso(double pArea, String pUso) {
        int numeroAsignado = misPisos.size() + 1;
        misPisos.add(new Piso(numeroAsignado, pArea, 100, pUso));
    }

    private Piso buscarPiso(int pNumero) {
        for (Piso p : misPisos) {
            if (p.getNumeroPiso() == pNumero) {
                return p;
            }
        }
        return null;
    }

    public String consultarUsoPiso(int pNumero) {
        Piso p = buscarPiso(pNumero);
        if (p != null) {
            return p.getUso();
        }
        return "Piso no encontrado";
    }

    public double consultarAreaPiso(int pNumero) {
        Piso p = buscarPiso(pNumero);
        if (p != null) {
            return p.getArea();
        }
        return 0.0;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Edificio: ").append(nombre).append("\n");
        for (Piso p : misPisos) {
            sb.append(" - ").append(p.toString()).append("\n");
        }
        return sb.toString();
    }
}