public class CasetaPeaje {
    private int numeroCaseta;
    private String nombreAutopista;
    private double totalCobrado;
    private static int cantidadCasetas = 0;

    // Constantes de tarifas para evitar valores "quemados"
    private final double TARIFA_PARTICULAR = 100.0;
    private final double TARIFA_CARGA_LIVIANA = 200.0;
    private final double TARIFA_CARGA = 500.0;
    private final double TARIFA_MOTO = 75.0;

    public CasetaPeaje(String pNombreAutopista) {
        cantidadCasetas++;
        numeroCaseta = cantidadCasetas;
        nombreAutopista = pNombreAutopista;
        totalCobrado = 0.0;
    }

    public void cobrarPeaje(Vehiculo obj) {
        switch (obj.getTipo().toLowerCase()) {
            case "particular":
                totalCobrado += TARIFA_PARTICULAR;
                break;
            case "carga liviana":
                totalCobrado += TARIFA_CARGA_LIVIANA;
                break;
            case "carga":
                totalCobrado += TARIFA_CARGA;
                break;
            case "moto":
                totalCobrado += TARIFA_MOTO;
                break;
            default:
                // Si el tipo no coincide, no se aplica cobro o se ignora
                break;
        }
    }

    public double getTotalCobrado() {
        return totalCobrado;
    }

    public String toString() {
        return "Caseta #" + numeroCaseta + " (" + nombreAutopista + ") - Total Recaudado: ₡" + totalCobrado;
    }
}