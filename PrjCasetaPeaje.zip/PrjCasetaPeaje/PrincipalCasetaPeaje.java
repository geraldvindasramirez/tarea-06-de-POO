public class PrincipalCasetaPeaje {
    public static void main(String[] args) {
        System.out.println("=== PRUEBA CASETA DE PEAJE - Gerald Vindas ===");
        
        CasetaPeaje caseta1 = new CasetaPeaje("Ruta 27");
        
        Vehiculo v1 = new Vehiculo("ABC-123", "particular");
        Vehiculo v2 = new Vehiculo("XYZ-789", "carga");
        Vehiculo v3 = new Vehiculo("MOTO-55", "moto");
        
        caseta1.cobrarPeaje(v1);
        caseta1.cobrarPeaje(v2);
        caseta1.cobrarPeaje(v3);
        
        System.out.println(caseta1);
    }
}