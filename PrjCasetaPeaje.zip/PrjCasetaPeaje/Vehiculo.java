public class Vehiculo {
    private String placa;
    private String tipo; // "particular", "carga liviana", "carga", "moto"

    public Vehiculo(String pPlaca, String pTipo) {
        placa = pPlaca;
        tipo = pTipo;
    }

    public String getPlaca() { return placa; }
    public String getTipo() { return tipo; }

    public String toString() {
        return "Vehículo Placa: " + placa + " | Tipo: " + tipo;
    }
}